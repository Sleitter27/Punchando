﻿namespace DSR_System
{
    partial class ucUnload
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucUnload));
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtRoute = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.dataGridViewUnload = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.ItemName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LoadCases = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LoadBottle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnloadCases = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnloadBottle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SaleBottle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Value = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtCash = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtCheque = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtCredit = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtDiscount = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtExpenses = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel9 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtExpairi = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel10 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtGasOut = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel11 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtGiveGoods = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtShortEmpty = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel12 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel13 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtExcessEmpty = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel14 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtGaveGoods = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.lblShortExcess = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btnSave = new Bunifu.Framework.UI.BunifuFlatButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dtpDate = new Bunifu.Framework.UI.BunifuDatepicker();
            this.lblTotBottle = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblTotValue = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btnProcess = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnLoad = new Bunifu.Framework.UI.BunifuFlatButton();
            this.cbxDSRname = new Bunifu.Framework.UI.BunifuDropdown();
            this.bunifuCustomLabel15 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel16 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel17 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel18 = new Bunifu.Framework.UI.BunifuCustomLabel();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUnload)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(432, 11);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(82, 17);
            this.bunifuCustomLabel3.TabIndex = 11;
            this.bunifuCustomLabel3.Text = "DSR Name:";
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(222, 11);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(42, 17);
            this.bunifuCustomLabel2.TabIndex = 9;
            this.bunifuCustomLabel2.Text = "Date:";
            // 
            // txtRoute
            // 
            this.txtRoute.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtRoute.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(234)))), ((int)(((byte)(235)))));
            this.txtRoute.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtRoute.BorderThickness = 3;
            this.txtRoute.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtRoute.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtRoute.ForeColor = System.Drawing.Color.White;
            this.txtRoute.isPassword = false;
            this.txtRoute.Location = new System.Drawing.Point(12, 31);
            this.txtRoute.Margin = new System.Windows.Forms.Padding(4);
            this.txtRoute.Name = "txtRoute";
            this.txtRoute.Size = new System.Drawing.Size(180, 30);
            this.txtRoute.TabIndex = 8;
            this.txtRoute.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(12, 11);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(50, 17);
            this.bunifuCustomLabel1.TabIndex = 7;
            this.bunifuCustomLabel1.Text = "Route:";
            // 
            // dataGridViewUnload
            // 
            this.dataGridViewUnload.AllowUserToAddRows = false;
            this.dataGridViewUnload.AllowUserToResizeColumns = false;
            this.dataGridViewUnload.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridViewUnload.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewUnload.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewUnload.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewUnload.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGridViewUnload.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SeaGreen;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewUnload.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewUnload.ColumnHeadersHeight = 45;
            this.dataGridViewUnload.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridViewUnload.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemName,
            this.LoadCases,
            this.LoadBottle,
            this.UnloadCases,
            this.UnloadBottle,
            this.SaleBottle,
            this.Value});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewUnload.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewUnload.DoubleBuffered = true;
            this.dataGridViewUnload.EnableHeadersVisualStyles = false;
            this.dataGridViewUnload.HeaderBgColor = System.Drawing.Color.SeaGreen;
            this.dataGridViewUnload.HeaderForeColor = System.Drawing.Color.White;
            this.dataGridViewUnload.Location = new System.Drawing.Point(12, 72);
            this.dataGridViewUnload.MultiSelect = false;
            this.dataGridViewUnload.Name = "dataGridViewUnload";
            this.dataGridViewUnload.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dataGridViewUnload.RowHeadersVisible = false;
            this.dataGridViewUnload.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewUnload.RowTemplate.Height = 30;
            this.dataGridViewUnload.Size = new System.Drawing.Size(706, 271);
            this.dataGridViewUnload.TabIndex = 0;
            this.dataGridViewUnload.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewUnload_CellEndEdit);
            this.dataGridViewUnload.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dataGridViewUnload_EditingControlShowing);
            // 
            // ItemName
            // 
            this.ItemName.HeaderText = "Item Name";
            this.ItemName.Name = "ItemName";
            this.ItemName.Width = 255;
            // 
            // LoadCases
            // 
            this.LoadCases.HeaderText = "Load Case";
            this.LoadCases.Name = "LoadCases";
            this.LoadCases.Width = 60;
            // 
            // LoadBottle
            // 
            this.LoadBottle.HeaderText = "Load Bottle";
            this.LoadBottle.Name = "LoadBottle";
            this.LoadBottle.Width = 60;
            // 
            // UnloadCases
            // 
            this.UnloadCases.HeaderText = "Unload Case";
            this.UnloadCases.Name = "UnloadCases";
            this.UnloadCases.Width = 60;
            // 
            // UnloadBottle
            // 
            this.UnloadBottle.HeaderText = "Unload Bottle";
            this.UnloadBottle.Name = "UnloadBottle";
            this.UnloadBottle.Width = 60;
            // 
            // SaleBottle
            // 
            this.SaleBottle.HeaderText = "Sale Bottle";
            this.SaleBottle.Name = "SaleBottle";
            this.SaleBottle.Width = 60;
            // 
            // Value
            // 
            this.Value.HeaderText = "Value";
            this.Value.Name = "Value";
            this.Value.Width = 150;
            // 
            // txtCash
            // 
            this.txtCash.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtCash.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(234)))), ((int)(((byte)(235)))));
            this.txtCash.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtCash.BorderThickness = 3;
            this.txtCash.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCash.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtCash.ForeColor = System.Drawing.Color.White;
            this.txtCash.isPassword = false;
            this.txtCash.Location = new System.Drawing.Point(81, 15);
            this.txtCash.Margin = new System.Windows.Forms.Padding(4);
            this.txtCash.Name = "txtCash";
            this.txtCash.Size = new System.Drawing.Size(120, 25);
            this.txtCash.TabIndex = 13;
            this.txtCash.Text = "0.00";
            this.txtCash.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtCash.Click += new System.EventHandler(this.txtCash_Click);
            this.txtCash.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCash_KeyPress);
            this.txtCash.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtCash_MouseClick);
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel4.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(15, 20);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(38, 15);
            this.bunifuCustomLabel4.TabIndex = 14;
            this.bunifuCustomLabel4.Text = "Cash:";
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(15, 56);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(53, 15);
            this.bunifuCustomLabel5.TabIndex = 16;
            this.bunifuCustomLabel5.Text = "Cheque:";
            // 
            // txtCheque
            // 
            this.txtCheque.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtCheque.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(234)))), ((int)(((byte)(235)))));
            this.txtCheque.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtCheque.BorderThickness = 3;
            this.txtCheque.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCheque.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtCheque.ForeColor = System.Drawing.Color.White;
            this.txtCheque.isPassword = false;
            this.txtCheque.Location = new System.Drawing.Point(81, 51);
            this.txtCheque.Margin = new System.Windows.Forms.Padding(4);
            this.txtCheque.Name = "txtCheque";
            this.txtCheque.Size = new System.Drawing.Size(120, 25);
            this.txtCheque.TabIndex = 15;
            this.txtCheque.Text = "0.00";
            this.txtCheque.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtCheque.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCheque_KeyPress);
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel6.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(15, 92);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(42, 15);
            this.bunifuCustomLabel6.TabIndex = 18;
            this.bunifuCustomLabel6.Text = "Credit:";
            // 
            // txtCredit
            // 
            this.txtCredit.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtCredit.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(234)))), ((int)(((byte)(235)))));
            this.txtCredit.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtCredit.BorderThickness = 3;
            this.txtCredit.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCredit.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtCredit.ForeColor = System.Drawing.Color.White;
            this.txtCredit.isPassword = false;
            this.txtCredit.Location = new System.Drawing.Point(81, 87);
            this.txtCredit.Margin = new System.Windows.Forms.Padding(4);
            this.txtCredit.Name = "txtCredit";
            this.txtCredit.Size = new System.Drawing.Size(120, 25);
            this.txtCredit.TabIndex = 17;
            this.txtCredit.Text = "0.00";
            this.txtCredit.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtCredit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCredit_KeyPress);
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel7.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(15, 127);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(58, 15);
            this.bunifuCustomLabel7.TabIndex = 20;
            this.bunifuCustomLabel7.Text = "Discount:";
            // 
            // txtDiscount
            // 
            this.txtDiscount.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtDiscount.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(234)))), ((int)(((byte)(235)))));
            this.txtDiscount.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtDiscount.BorderThickness = 3;
            this.txtDiscount.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDiscount.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtDiscount.ForeColor = System.Drawing.Color.White;
            this.txtDiscount.isPassword = false;
            this.txtDiscount.Location = new System.Drawing.Point(81, 122);
            this.txtDiscount.Margin = new System.Windows.Forms.Padding(4);
            this.txtDiscount.Name = "txtDiscount";
            this.txtDiscount.Size = new System.Drawing.Size(120, 25);
            this.txtDiscount.TabIndex = 19;
            this.txtDiscount.Text = "0.00";
            this.txtDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtDiscount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDiscount_KeyPress);
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel8.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(15, 164);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(64, 15);
            this.bunifuCustomLabel8.TabIndex = 22;
            this.bunifuCustomLabel8.Text = "Expenses:";
            // 
            // txtExpenses
            // 
            this.txtExpenses.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtExpenses.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(234)))), ((int)(((byte)(235)))));
            this.txtExpenses.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtExpenses.BorderThickness = 3;
            this.txtExpenses.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtExpenses.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtExpenses.ForeColor = System.Drawing.Color.White;
            this.txtExpenses.isPassword = false;
            this.txtExpenses.Location = new System.Drawing.Point(81, 159);
            this.txtExpenses.Margin = new System.Windows.Forms.Padding(4);
            this.txtExpenses.Name = "txtExpenses";
            this.txtExpenses.Size = new System.Drawing.Size(120, 25);
            this.txtExpenses.TabIndex = 21;
            this.txtExpenses.Text = "0.00";
            this.txtExpenses.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtExpenses.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtExpenses_KeyPress);
            // 
            // bunifuCustomLabel9
            // 
            this.bunifuCustomLabel9.AutoSize = true;
            this.bunifuCustomLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel9.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel9.Location = new System.Drawing.Point(220, 20);
            this.bunifuCustomLabel9.Name = "bunifuCustomLabel9";
            this.bunifuCustomLabel9.Size = new System.Drawing.Size(48, 15);
            this.bunifuCustomLabel9.TabIndex = 24;
            this.bunifuCustomLabel9.Text = "Expairi:";
            // 
            // txtExpairi
            // 
            this.txtExpairi.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtExpairi.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(234)))), ((int)(((byte)(235)))));
            this.txtExpairi.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtExpairi.BorderThickness = 3;
            this.txtExpairi.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtExpairi.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtExpairi.ForeColor = System.Drawing.Color.White;
            this.txtExpairi.isPassword = false;
            this.txtExpairi.Location = new System.Drawing.Point(312, 15);
            this.txtExpairi.Margin = new System.Windows.Forms.Padding(4);
            this.txtExpairi.Name = "txtExpairi";
            this.txtExpairi.Size = new System.Drawing.Size(120, 25);
            this.txtExpairi.TabIndex = 23;
            this.txtExpairi.Text = "0.00";
            this.txtExpairi.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtExpairi.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtExpairi_KeyPress);
            // 
            // bunifuCustomLabel10
            // 
            this.bunifuCustomLabel10.AutoSize = true;
            this.bunifuCustomLabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel10.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel10.Location = new System.Drawing.Point(220, 56);
            this.bunifuCustomLabel10.Name = "bunifuCustomLabel10";
            this.bunifuCustomLabel10.Size = new System.Drawing.Size(52, 15);
            this.bunifuCustomLabel10.TabIndex = 26;
            this.bunifuCustomLabel10.Text = "Gas out:";
            // 
            // txtGasOut
            // 
            this.txtGasOut.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtGasOut.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(234)))), ((int)(((byte)(235)))));
            this.txtGasOut.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtGasOut.BorderThickness = 3;
            this.txtGasOut.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtGasOut.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtGasOut.ForeColor = System.Drawing.Color.White;
            this.txtGasOut.isPassword = false;
            this.txtGasOut.Location = new System.Drawing.Point(312, 51);
            this.txtGasOut.Margin = new System.Windows.Forms.Padding(4);
            this.txtGasOut.Name = "txtGasOut";
            this.txtGasOut.Size = new System.Drawing.Size(120, 25);
            this.txtGasOut.TabIndex = 25;
            this.txtGasOut.Text = "0.00";
            this.txtGasOut.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtGasOut.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGasOut_KeyPress);
            // 
            // bunifuCustomLabel11
            // 
            this.bunifuCustomLabel11.AutoSize = true;
            this.bunifuCustomLabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel11.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel11.Location = new System.Drawing.Point(220, 92);
            this.bunifuCustomLabel11.Name = "bunifuCustomLabel11";
            this.bunifuCustomLabel11.Size = new System.Drawing.Size(86, 15);
            this.bunifuCustomLabel11.TabIndex = 28;
            this.bunifuCustomLabel11.Text = "To give goods:";
            // 
            // txtGiveGoods
            // 
            this.txtGiveGoods.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtGiveGoods.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(234)))), ((int)(((byte)(235)))));
            this.txtGiveGoods.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtGiveGoods.BorderThickness = 3;
            this.txtGiveGoods.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtGiveGoods.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtGiveGoods.ForeColor = System.Drawing.Color.White;
            this.txtGiveGoods.isPassword = false;
            this.txtGiveGoods.Location = new System.Drawing.Point(312, 87);
            this.txtGiveGoods.Margin = new System.Windows.Forms.Padding(4);
            this.txtGiveGoods.Name = "txtGiveGoods";
            this.txtGiveGoods.Size = new System.Drawing.Size(120, 25);
            this.txtGiveGoods.TabIndex = 27;
            this.txtGiveGoods.Text = "0.00";
            this.txtGiveGoods.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtGiveGoods.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGiveGoods_KeyPress);
            // 
            // txtShortEmpty
            // 
            this.txtShortEmpty.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtShortEmpty.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(234)))), ((int)(((byte)(235)))));
            this.txtShortEmpty.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtShortEmpty.BorderThickness = 3;
            this.txtShortEmpty.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtShortEmpty.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtShortEmpty.ForeColor = System.Drawing.Color.White;
            this.txtShortEmpty.isPassword = false;
            this.txtShortEmpty.Location = new System.Drawing.Point(108, 13);
            this.txtShortEmpty.Margin = new System.Windows.Forms.Padding(4);
            this.txtShortEmpty.Name = "txtShortEmpty";
            this.txtShortEmpty.Size = new System.Drawing.Size(120, 25);
            this.txtShortEmpty.TabIndex = 27;
            this.txtShortEmpty.Text = "0.00";
            this.txtShortEmpty.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtShortEmpty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtShortEmpty_KeyPress);
            // 
            // bunifuCustomLabel12
            // 
            this.bunifuCustomLabel12.AutoSize = true;
            this.bunifuCustomLabel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel12.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel12.Location = new System.Drawing.Point(11, 18);
            this.bunifuCustomLabel12.Name = "bunifuCustomLabel12";
            this.bunifuCustomLabel12.Size = new System.Drawing.Size(76, 15);
            this.bunifuCustomLabel12.TabIndex = 28;
            this.bunifuCustomLabel12.Text = "Short Empty:";
            // 
            // bunifuCustomLabel13
            // 
            this.bunifuCustomLabel13.AutoSize = true;
            this.bunifuCustomLabel13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel13.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel13.Location = new System.Drawing.Point(11, 50);
            this.bunifuCustomLabel13.Name = "bunifuCustomLabel13";
            this.bunifuCustomLabel13.Size = new System.Drawing.Size(86, 15);
            this.bunifuCustomLabel13.TabIndex = 30;
            this.bunifuCustomLabel13.Text = "Excess Empty:";
            // 
            // txtExcessEmpty
            // 
            this.txtExcessEmpty.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtExcessEmpty.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(234)))), ((int)(((byte)(235)))));
            this.txtExcessEmpty.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtExcessEmpty.BorderThickness = 3;
            this.txtExcessEmpty.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtExcessEmpty.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtExcessEmpty.ForeColor = System.Drawing.Color.White;
            this.txtExcessEmpty.isPassword = false;
            this.txtExcessEmpty.Location = new System.Drawing.Point(108, 45);
            this.txtExcessEmpty.Margin = new System.Windows.Forms.Padding(4);
            this.txtExcessEmpty.Name = "txtExcessEmpty";
            this.txtExcessEmpty.Size = new System.Drawing.Size(120, 25);
            this.txtExcessEmpty.TabIndex = 29;
            this.txtExcessEmpty.Text = "0.00";
            this.txtExcessEmpty.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtExcessEmpty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtExcessEmpty_KeyPress);
            // 
            // bunifuCustomLabel14
            // 
            this.bunifuCustomLabel14.AutoSize = true;
            this.bunifuCustomLabel14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel14.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel14.Location = new System.Drawing.Point(220, 125);
            this.bunifuCustomLabel14.Name = "bunifuCustomLabel14";
            this.bunifuCustomLabel14.Size = new System.Drawing.Size(90, 15);
            this.bunifuCustomLabel14.TabIndex = 32;
            this.bunifuCustomLabel14.Text = "To gave goods:";
            // 
            // txtGaveGoods
            // 
            this.txtGaveGoods.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtGaveGoods.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(234)))), ((int)(((byte)(235)))));
            this.txtGaveGoods.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.txtGaveGoods.BorderThickness = 3;
            this.txtGaveGoods.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtGaveGoods.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtGaveGoods.ForeColor = System.Drawing.Color.White;
            this.txtGaveGoods.isPassword = false;
            this.txtGaveGoods.Location = new System.Drawing.Point(312, 122);
            this.txtGaveGoods.Margin = new System.Windows.Forms.Padding(4);
            this.txtGaveGoods.Name = "txtGaveGoods";
            this.txtGaveGoods.Size = new System.Drawing.Size(120, 25);
            this.txtGaveGoods.TabIndex = 31;
            this.txtGaveGoods.Text = "0.00";
            this.txtGaveGoods.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtGaveGoods.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGaveGoods_KeyPress);
            // 
            // lblShortExcess
            // 
            this.lblShortExcess.AutoSize = true;
            this.lblShortExcess.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShortExcess.ForeColor = System.Drawing.Color.White;
            this.lblShortExcess.Location = new System.Drawing.Point(533, 481);
            this.lblShortExcess.Name = "lblShortExcess";
            this.lblShortExcess.Size = new System.Drawing.Size(0, 39);
            this.lblShortExcess.TabIndex = 33;
            // 
            // btnSave
            // 
            this.btnSave.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSave.BorderRadius = 0;
            this.btnSave.ButtonText = "SAVE";
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.DisabledColor = System.Drawing.Color.Gray;
            this.btnSave.Iconcolor = System.Drawing.Color.Transparent;
            this.btnSave.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnSave.Iconimage")));
            this.btnSave.Iconimage_right = null;
            this.btnSave.Iconimage_right_Selected = null;
            this.btnSave.Iconimage_Selected = null;
            this.btnSave.IconMarginLeft = 0;
            this.btnSave.IconMarginRight = 0;
            this.btnSave.IconRightVisible = true;
            this.btnSave.IconRightZoom = 0D;
            this.btnSave.IconVisible = true;
            this.btnSave.IconZoom = 90D;
            this.btnSave.IsTab = false;
            this.btnSave.Location = new System.Drawing.Point(600, 551);
            this.btnSave.Name = "btnSave";
            this.btnSave.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnSave.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnSave.OnHoverTextColor = System.Drawing.Color.White;
            this.btnSave.selected = false;
            this.btnSave.Size = new System.Drawing.Size(123, 36);
            this.btnSave.TabIndex = 34;
            this.btnSave.Text = "SAVE";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Textcolor = System.Drawing.Color.White;
            this.btnSave.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.bunifuCustomLabel14);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel10);
            this.groupBox1.Controls.Add(this.txtGaveGoods);
            this.groupBox1.Controls.Add(this.txtGasOut);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel9);
            this.groupBox1.Controls.Add(this.txtExpairi);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel8);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel11);
            this.groupBox1.Controls.Add(this.txtExpenses);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel7);
            this.groupBox1.Controls.Add(this.txtGiveGoods);
            this.groupBox1.Controls.Add(this.txtDiscount);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel6);
            this.groupBox1.Controls.Add(this.txtCredit);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel5);
            this.groupBox1.Controls.Add(this.txtCheque);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel4);
            this.groupBox1.Controls.Add(this.txtCash);
            this.groupBox1.Location = new System.Drawing.Point(12, 387);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(450, 200);
            this.groupBox1.TabIndex = 35;
            this.groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.bunifuCustomLabel13);
            this.groupBox2.Controls.Add(this.txtExcessEmpty);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel12);
            this.groupBox2.Controls.Add(this.txtShortEmpty);
            this.groupBox2.Location = new System.Drawing.Point(472, 386);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(247, 79);
            this.groupBox2.TabIndex = 36;
            this.groupBox2.TabStop = false;
            // 
            // dtpDate
            // 
            this.dtpDate.BackColor = System.Drawing.Color.SeaGreen;
            this.dtpDate.BorderRadius = 0;
            this.dtpDate.ForeColor = System.Drawing.Color.White;
            this.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDate.FormatCustom = null;
            this.dtpDate.Location = new System.Drawing.Point(222, 31);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(180, 30);
            this.dtpDate.TabIndex = 37;
            this.dtpDate.Value = new System.DateTime(2018, 3, 13, 23, 16, 30, 72);
            // 
            // lblTotBottle
            // 
            this.lblTotBottle.AutoSize = true;
            this.lblTotBottle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotBottle.ForeColor = System.Drawing.Color.Red;
            this.lblTotBottle.Location = new System.Drawing.Point(298, 360);
            this.lblTotBottle.Name = "lblTotBottle";
            this.lblTotBottle.Size = new System.Drawing.Size(0, 17);
            this.lblTotBottle.TabIndex = 27;
            // 
            // lblTotValue
            // 
            this.lblTotValue.AutoSize = true;
            this.lblTotValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotValue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lblTotValue.Location = new System.Drawing.Point(546, 360);
            this.lblTotValue.Name = "lblTotValue";
            this.lblTotValue.Size = new System.Drawing.Size(0, 17);
            this.lblTotValue.TabIndex = 38;
            // 
            // btnProcess
            // 
            this.btnProcess.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnProcess.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnProcess.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnProcess.BorderRadius = 0;
            this.btnProcess.ButtonText = "PROCESS";
            this.btnProcess.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProcess.DisabledColor = System.Drawing.Color.Gray;
            this.btnProcess.Iconcolor = System.Drawing.Color.Transparent;
            this.btnProcess.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnProcess.Iconimage")));
            this.btnProcess.Iconimage_right = null;
            this.btnProcess.Iconimage_right_Selected = null;
            this.btnProcess.Iconimage_Selected = null;
            this.btnProcess.IconMarginLeft = 0;
            this.btnProcess.IconMarginRight = 0;
            this.btnProcess.IconRightVisible = true;
            this.btnProcess.IconRightZoom = 0D;
            this.btnProcess.IconVisible = true;
            this.btnProcess.IconZoom = 90D;
            this.btnProcess.IsTab = false;
            this.btnProcess.Location = new System.Drawing.Point(472, 551);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnProcess.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnProcess.OnHoverTextColor = System.Drawing.Color.White;
            this.btnProcess.selected = false;
            this.btnProcess.Size = new System.Drawing.Size(123, 36);
            this.btnProcess.TabIndex = 39;
            this.btnProcess.Text = "PROCESS";
            this.btnProcess.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProcess.Textcolor = System.Drawing.Color.White;
            this.btnProcess.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProcess.Click += new System.EventHandler(this.btnProcess_Click);
            // 
            // btnLoad
            // 
            this.btnLoad.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnLoad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnLoad.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLoad.BorderRadius = 0;
            this.btnLoad.ButtonText = "LOAD";
            this.btnLoad.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLoad.DisabledColor = System.Drawing.Color.Gray;
            this.btnLoad.Iconcolor = System.Drawing.Color.Transparent;
            this.btnLoad.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnLoad.Iconimage")));
            this.btnLoad.Iconimage_right = null;
            this.btnLoad.Iconimage_right_Selected = null;
            this.btnLoad.Iconimage_Selected = null;
            this.btnLoad.IconMarginLeft = 0;
            this.btnLoad.IconMarginRight = 0;
            this.btnLoad.IconRightVisible = true;
            this.btnLoad.IconRightZoom = 0D;
            this.btnLoad.IconVisible = false;
            this.btnLoad.IconZoom = 90D;
            this.btnLoad.IsTab = false;
            this.btnLoad.Location = new System.Drawing.Point(633, 31);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnLoad.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnLoad.OnHoverTextColor = System.Drawing.Color.White;
            this.btnLoad.selected = false;
            this.btnLoad.Size = new System.Drawing.Size(81, 30);
            this.btnLoad.TabIndex = 40;
            this.btnLoad.Text = "LOAD";
            this.btnLoad.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnLoad.Textcolor = System.Drawing.Color.White;
            this.btnLoad.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // cbxDSRname
            // 
            this.cbxDSRname.BackColor = System.Drawing.Color.Transparent;
            this.cbxDSRname.BorderRadius = 3;
            this.cbxDSRname.DisabledColor = System.Drawing.Color.Gray;
            this.cbxDSRname.ForeColor = System.Drawing.Color.White;
            this.cbxDSRname.Items = new string[0];
            this.cbxDSRname.Location = new System.Drawing.Point(433, 31);
            this.cbxDSRname.Name = "cbxDSRname";
            this.cbxDSRname.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.cbxDSRname.onHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.cbxDSRname.selectedIndex = -1;
            this.cbxDSRname.Size = new System.Drawing.Size(180, 30);
            this.cbxDSRname.TabIndex = 42;
            // 
            // bunifuCustomLabel15
            // 
            this.bunifuCustomLabel15.AutoSize = true;
            this.bunifuCustomLabel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel15.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel15.Location = new System.Drawing.Point(176, 360);
            this.bunifuCustomLabel15.Name = "bunifuCustomLabel15";
            this.bunifuCustomLabel15.Size = new System.Drawing.Size(121, 17);
            this.bunifuCustomLabel15.TabIndex = 33;
            this.bunifuCustomLabel15.Text = "Total sales Bottle:";
            // 
            // bunifuCustomLabel16
            // 
            this.bunifuCustomLabel16.AutoSize = true;
            this.bunifuCustomLabel16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel16.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel16.Location = new System.Drawing.Point(435, 360);
            this.bunifuCustomLabel16.Name = "bunifuCustomLabel16";
            this.bunifuCustomLabel16.Size = new System.Drawing.Size(84, 17);
            this.bunifuCustomLabel16.TabIndex = 43;
            this.bunifuCustomLabel16.Text = "Total Value:";
            // 
            // bunifuCustomLabel17
            // 
            this.bunifuCustomLabel17.AutoSize = true;
            this.bunifuCustomLabel17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel17.ForeColor = System.Drawing.Color.Yellow;
            this.bunifuCustomLabel17.Location = new System.Drawing.Point(510, 531);
            this.bunifuCustomLabel17.Name = "bunifuCustomLabel17";
            this.bunifuCustomLabel17.Size = new System.Drawing.Size(166, 13);
            this.bunifuCustomLabel17.TabIndex = 44;
            this.bunifuCustomLabel17.Text = "Please double check your record.";
            // 
            // bunifuCustomLabel18
            // 
            this.bunifuCustomLabel18.AutoSize = true;
            this.bunifuCustomLabel18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel18.Location = new System.Drawing.Point(521, 360);
            this.bunifuCustomLabel18.Name = "bunifuCustomLabel18";
            this.bunifuCustomLabel18.Size = new System.Drawing.Size(25, 17);
            this.bunifuCustomLabel18.TabIndex = 45;
            this.bunifuCustomLabel18.Text = "Rs";
            // 
            // ucUnload
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(44)))), ((int)(((byte)(52)))));
            this.Controls.Add(this.bunifuCustomLabel18);
            this.Controls.Add(this.bunifuCustomLabel17);
            this.Controls.Add(this.bunifuCustomLabel16);
            this.Controls.Add(this.bunifuCustomLabel15);
            this.Controls.Add(this.cbxDSRname);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.btnProcess);
            this.Controls.Add(this.lblTotValue);
            this.Controls.Add(this.lblTotBottle);
            this.Controls.Add(this.dtpDate);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblShortExcess);
            this.Controls.Add(this.dataGridViewUnload);
            this.Controls.Add(this.bunifuCustomLabel3);
            this.Controls.Add(this.bunifuCustomLabel2);
            this.Controls.Add(this.txtRoute);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.Name = "ucUnload";
            this.Size = new System.Drawing.Size(730, 595);
            this.Load += new System.EventHandler(this.ucUnload_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUnload)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtRoute;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomDataGrid dataGridViewUnload;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtCash;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtCheque;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtCredit;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtDiscount;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtExpenses;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel9;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtExpairi;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel10;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtGasOut;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel11;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtGiveGoods;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtShortEmpty;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel12;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel13;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtExcessEmpty;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel14;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtGaveGoods;
        private Bunifu.Framework.UI.BunifuCustomLabel lblShortExcess;
        private Bunifu.Framework.UI.BunifuFlatButton btnSave;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private Bunifu.Framework.UI.BunifuDatepicker dtpDate;
        private Bunifu.Framework.UI.BunifuCustomLabel lblTotBottle;
        private Bunifu.Framework.UI.BunifuCustomLabel lblTotValue;
        private Bunifu.Framework.UI.BunifuFlatButton btnProcess;
        private Bunifu.Framework.UI.BunifuFlatButton btnLoad;
        private Bunifu.Framework.UI.BunifuDropdown cbxDSRname;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel15;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel16;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemName;
        private System.Windows.Forms.DataGridViewTextBoxColumn LoadCases;
        private System.Windows.Forms.DataGridViewTextBoxColumn LoadBottle;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnloadCases;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnloadBottle;
        private System.Windows.Forms.DataGridViewTextBoxColumn SaleBottle;
        private System.Windows.Forms.DataGridViewTextBoxColumn Value;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel17;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel18;
    }
}
