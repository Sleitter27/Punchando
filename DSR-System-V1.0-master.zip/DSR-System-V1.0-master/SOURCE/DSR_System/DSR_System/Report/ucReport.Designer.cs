﻿namespace DSR_System
{
    partial class ucReport
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnnProcess = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnDeliveryRptBtn = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnLURptBtn = new Bunifu.Framework.UI.BunifuFlatButton();
            this.crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnnProcess);
            this.panel1.Controls.Add(this.btnDeliveryRptBtn);
            this.panel1.Controls.Add(this.btnLURptBtn);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(730, 62);
            this.panel1.TabIndex = 0;
            // 
            // btnnProcess
            // 
            this.btnnProcess.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnnProcess.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnnProcess.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnnProcess.BorderRadius = 0;
            this.btnnProcess.ButtonText = "PROCESS";
            this.btnnProcess.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnnProcess.DisabledColor = System.Drawing.Color.Gray;
            this.btnnProcess.Iconcolor = System.Drawing.Color.Transparent;
            this.btnnProcess.Iconimage = null;
            this.btnnProcess.Iconimage_right = null;
            this.btnnProcess.Iconimage_right_Selected = null;
            this.btnnProcess.Iconimage_Selected = null;
            this.btnnProcess.IconMarginLeft = 0;
            this.btnnProcess.IconMarginRight = 0;
            this.btnnProcess.IconRightVisible = true;
            this.btnnProcess.IconRightZoom = 0D;
            this.btnnProcess.IconVisible = true;
            this.btnnProcess.IconZoom = 90D;
            this.btnnProcess.IsTab = false;
            this.btnnProcess.Location = new System.Drawing.Point(388, 7);
            this.btnnProcess.Name = "btnnProcess";
            this.btnnProcess.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnnProcess.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnnProcess.OnHoverTextColor = System.Drawing.Color.White;
            this.btnnProcess.selected = false;
            this.btnnProcess.Size = new System.Drawing.Size(159, 47);
            this.btnnProcess.TabIndex = 4;
            this.btnnProcess.Text = "PROCESS";
            this.btnnProcess.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnnProcess.Textcolor = System.Drawing.Color.White;
            this.btnnProcess.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnDeliveryRptBtn
            // 
            this.btnDeliveryRptBtn.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnDeliveryRptBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnDeliveryRptBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDeliveryRptBtn.BorderRadius = 0;
            this.btnDeliveryRptBtn.ButtonText = "Summery of Delivery";
            this.btnDeliveryRptBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDeliveryRptBtn.DisabledColor = System.Drawing.Color.Gray;
            this.btnDeliveryRptBtn.Iconcolor = System.Drawing.Color.Transparent;
            this.btnDeliveryRptBtn.Iconimage = null;
            this.btnDeliveryRptBtn.Iconimage_right = null;
            this.btnDeliveryRptBtn.Iconimage_right_Selected = null;
            this.btnDeliveryRptBtn.Iconimage_Selected = null;
            this.btnDeliveryRptBtn.IconMarginLeft = 0;
            this.btnDeliveryRptBtn.IconMarginRight = 0;
            this.btnDeliveryRptBtn.IconRightVisible = true;
            this.btnDeliveryRptBtn.IconRightZoom = 0D;
            this.btnDeliveryRptBtn.IconVisible = true;
            this.btnDeliveryRptBtn.IconZoom = 90D;
            this.btnDeliveryRptBtn.IsTab = false;
            this.btnDeliveryRptBtn.Location = new System.Drawing.Point(7, 7);
            this.btnDeliveryRptBtn.Name = "btnDeliveryRptBtn";
            this.btnDeliveryRptBtn.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnDeliveryRptBtn.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnDeliveryRptBtn.OnHoverTextColor = System.Drawing.Color.White;
            this.btnDeliveryRptBtn.selected = false;
            this.btnDeliveryRptBtn.Size = new System.Drawing.Size(159, 47);
            this.btnDeliveryRptBtn.TabIndex = 3;
            this.btnDeliveryRptBtn.Text = "Summery of Delivery";
            this.btnDeliveryRptBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDeliveryRptBtn.Textcolor = System.Drawing.Color.White;
            this.btnDeliveryRptBtn.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeliveryRptBtn.Click += new System.EventHandler(this.btnDeliveryRptBtn_Click);
            // 
            // btnLURptBtn
            // 
            this.btnLURptBtn.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnLURptBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnLURptBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLURptBtn.BorderRadius = 0;
            this.btnLURptBtn.ButtonText = "Load and Unload";
            this.btnLURptBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLURptBtn.DisabledColor = System.Drawing.Color.Gray;
            this.btnLURptBtn.Iconcolor = System.Drawing.Color.Transparent;
            this.btnLURptBtn.Iconimage = null;
            this.btnLURptBtn.Iconimage_right = null;
            this.btnLURptBtn.Iconimage_right_Selected = null;
            this.btnLURptBtn.Iconimage_Selected = null;
            this.btnLURptBtn.IconMarginLeft = 0;
            this.btnLURptBtn.IconMarginRight = 0;
            this.btnLURptBtn.IconRightVisible = true;
            this.btnLURptBtn.IconRightZoom = 0D;
            this.btnLURptBtn.IconVisible = true;
            this.btnLURptBtn.IconZoom = 90D;
            this.btnLURptBtn.IsTab = false;
            this.btnLURptBtn.Location = new System.Drawing.Point(198, 7);
            this.btnLURptBtn.Name = "btnLURptBtn";
            this.btnLURptBtn.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnLURptBtn.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnLURptBtn.OnHoverTextColor = System.Drawing.Color.White;
            this.btnLURptBtn.selected = false;
            this.btnLURptBtn.Size = new System.Drawing.Size(159, 47);
            this.btnLURptBtn.TabIndex = 2;
            this.btnLURptBtn.Text = "Load and Unload";
            this.btnLURptBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnLURptBtn.Textcolor = System.Drawing.Color.White;
            this.btnLURptBtn.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // crystalReportViewer1
            // 
            this.crystalReportViewer1.ActiveViewIndex = -1;
            this.crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewer1.Cursor = System.Windows.Forms.Cursors.Default;
            this.crystalReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crystalReportViewer1.Location = new System.Drawing.Point(0, 62);
            this.crystalReportViewer1.Name = "crystalReportViewer1";
            this.crystalReportViewer1.Size = new System.Drawing.Size(730, 533);
            this.crystalReportViewer1.TabIndex = 1;
            this.crystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None;
            // 
            // ucReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(44)))), ((int)(((byte)(52)))));
            this.Controls.Add(this.crystalReportViewer1);
            this.Controls.Add(this.panel1);
            this.Name = "ucReport";
            this.Size = new System.Drawing.Size(730, 595);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuFlatButton btnDeliveryRptBtn;
        private Bunifu.Framework.UI.BunifuFlatButton btnLURptBtn;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer1;
        private Bunifu.Framework.UI.BunifuFlatButton btnnProcess;
    }
}
