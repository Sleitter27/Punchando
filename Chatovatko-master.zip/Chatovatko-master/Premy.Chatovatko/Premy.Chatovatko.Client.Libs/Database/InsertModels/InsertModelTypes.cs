﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Premy.Chatovatko.Client.Libs.Database.InsertModels
{
    public enum InsertModelTypes
    {
        ALARM,
        CONTACT,
        MESSAGE,
        MESSAGE_THREAD
    }
}
