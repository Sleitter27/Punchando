﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Premy.Chatovatko.Client.Libs.Database.JsonModels
{
    public enum JsonTypes
    {
        ALARM = 1,
        CONTACT = 2,
        MESSAGES_THREAD = 3,
        MESSAGES = 4
    }
}
