﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Premy.Chatovatko.Client.Libs.Database.UpdateModels
{
    public enum UpdateModelTypes
    {
        CONTACT,
        MESSAGE_THREAD
    }
}
