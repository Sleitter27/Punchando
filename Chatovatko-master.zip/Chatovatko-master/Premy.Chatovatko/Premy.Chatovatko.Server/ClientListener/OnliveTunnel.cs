﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Premy.Chatovatko.Server.ClientListener
{
    public class OnliveTunnel
    {

    }
}
