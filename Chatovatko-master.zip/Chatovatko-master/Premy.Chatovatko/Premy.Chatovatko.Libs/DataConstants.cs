﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Premy.Chatovatko.Libs
{
    public static class DataConstants
    {
        public static readonly int USER_NAME_MAX_LENGHT = 45;
    }
}
