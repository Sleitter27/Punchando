﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Premy.Chatovatko.Libs.DataTransmission.JsonModels
{
    public class ServerConnectionInfo
    {
        public int GodotID { get; set; }
        public bool Authenticated { get; set; }
    }
}
