﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace Premy.Chatovatko.Libs.Logging
{
    public interface ILoggable
    {

        String GetLogSource();
        
    }
}
