﻿Live Support Chat 
-----------------

LiveSupportChat is an open source simple online support chat demo application. It has used SignalR.

There are two pages :
 *OperatorLogin.aspx ---> operator can login here, and go to online support page
 *OnlineSupport.aspx ---> user chat page

This is 1-1 chat communication. If operator is chatting with user, other connected users will be stored in Queue object.
Once operator completes chat with first user, new user will be selected from queue and connected with operator.

It is working only on IE and Chrome browser.















