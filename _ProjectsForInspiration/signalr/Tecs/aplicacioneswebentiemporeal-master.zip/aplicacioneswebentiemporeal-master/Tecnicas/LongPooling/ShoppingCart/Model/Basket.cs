﻿namespace ShoppingCart.Model
{
    public class Basket
    {
        public BasketItem[] Items { get; set; }
    }
}
