﻿var sampleProductCategories = [
    {
        "products": [
            {
                "name": "Coca Cola",
                "price": 0.9
            },
            {
                "name": "Coca Cola Light",
                "price": 0.9
            },
            {
                "name": "Coca Cola Zero",
                "price": 0.9
            },
            {
                "name": "Coca Cola Zero Zero",
                "price": 0.9
            }
        ],
        "name": "Drinks"
    },
    {
        "products": [
            {
                "name": "Lays",
                "price": 1.2
            },
            {
                "name": "Lays Jamon",
                "price": 1.2
            },
            {
                "name": "Lays Campesinas",
                "price": 1.2
            },
            {
                "name": "Lays Onduladas",
                "price": 1.4
            }
        ],
        "name": "Snacks"
    },
    {
        "products": [
            {
                "name": "Chef Boyardee Big",
                "price": 6.0
            },
            {
                "name": "Sprout Organic Baby Food",
                "price": 7.2
            },
            {
                "name": "See Flavor & Size Options",
                "price": 9.0
            },
            {
                "name": "Liberated Cheddar",
                "price": 20.99
            }
        ],
        "name": "Lunches"
    },
    {
        "products": [
            {
                "name": "Frosted Mini-Wheats Kellogg's",
                "price": 3.0
            },
            {
                "name": "Kellogg's Raisin Bran Crunch",
                "price": 3.5
            },
            {
                "name": "Kellogg's Special K",
                "price":3.5
            },
            {
                "name": "Post Honey Bunches of Oats",
                "price": 4.85
            }
        ],
        "name": "Breakfast"
    }
];