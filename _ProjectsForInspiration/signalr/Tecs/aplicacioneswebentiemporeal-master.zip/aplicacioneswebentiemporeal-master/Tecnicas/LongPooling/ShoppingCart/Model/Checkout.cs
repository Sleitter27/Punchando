﻿namespace ShoppingCart.Model
{
    public class Checkout
    {
        public string OrderId { get; set; }
    }
}
