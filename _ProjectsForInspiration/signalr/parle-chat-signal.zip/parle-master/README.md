## Looking for LCSK (LiveChat Starter Kit)
Use the lcsk branch.


# Parle
I'm currently building a completely free and open source customer communcation platform.

This is ambitious, but I've built two big SaaS in the last 2 years, LeadFuze and
[Roadmap](https://roadmap.space) so I'm confident about this one.

This project is the main web application where agent talk to visitor and manage everything.



### What's the overall initial planned functionalities

#### Website/in-app messenger
Website visitors (leads) and in-app signed in users can start conversation with agents.

When user are not online, they will receive the messages via email.


#### Marketing automation
Create campaign based on user attributes, send email on key actions or behavior from your users.

This is actively in development at the moment.