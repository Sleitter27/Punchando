<!-- Love parle? Please consider supporting our collective:
👉  https://opencollective.com/parle/donate -->

Parle Version:
Elm version:
Browser and version:
OS: 

Please describe your deployment setup and any error message with the full stack trace.

Are you using an old version?
Have you checked the changelogs to see if your issue has been fixed in a later version?

https://github.com/parle-io/parle/blob/master/CHANGES.md